import 'package:flutter/material.dart';
import '../models/product.dart';
import 'details.dart';
class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Create a list of products
  final List<Product> products = [

    Product(
      name: 'Adidas',
      image: 'assets/img.png',
      price: 4000,
      description: 'best for running',
    ),
    Product(
      name: 'Nike',
      image: 'assets/img_1.png',
      price: 5000,
      description: 'best for running',
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product List'),
        backgroundColor: Colors.blueGrey[200],
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
          child: ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              Product product = products[index];
              return Card(
                child: ListTile(
                  leading: Image.asset(product.image),
                  title: Text(product.name),
                  subtitle: Text('\RS ${product.price}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Details(product: product),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
